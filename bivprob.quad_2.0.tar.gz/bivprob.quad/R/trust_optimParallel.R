
integrateArgs <- function(f, args){
  form <- formals(f)
  if(!is.null(form))
    for(i in seq_along(form))
      assign(names(form)[i], form[[i]])
  if(!is.null(args))
    for(i in seq_along(args))
      assign(names(args)[i], args[[i]])
  ff <- function(){}
  parent.env(environment(ff)) <- .GlobalEnv
  body(ff) <- body(f)
  if(any(names(form) == "..."))
    formals(ff) <- form[names(form) == "..."]
  ff
}

getFunctions <- function(f, args, firstArg, parnames){
  if(is.vector(firstArg))
    firstArg <- matrix(data=firstArg)
  lapply(seq_len(ncol(firstArg)), function(x){
    fa <- firstArg[,x]
    names(fa) <- parnames
    args[[names(formals(f))[1]]] <- fa
    integrateArgs(f=f, args=args)
  })
}


evalParallel <- function(cl, f, args, firstArg, parnames){
  funlist <- getFunctions(f=f, args=args, firstArg=firstArg, parnames=parnames)
  parallel::parLapply(cl=cl, X=funlist, fun=function(x) x())
}




trust.optimParallel <- function(par, fn, gr = NULL, ..., method = c("L-BFGS-B", "BFGS", "CG"),
                                lower = -Inf, upper = Inf, control = list(), hessian = FALSE,
                                parallel=list()){
  dots <- list(...)
  names(dots) <- c("yS","yO", "XO", "XS", "kS", "kO", "group","QP")
  method <- method[1]
  
  if(is.null(control$ndeps))
    control$ndeps <- 1e-3
  stopifnot(is.numeric(control$ndeps))
  
  if(is.null(control$fnscale)){
    fnscale <- 1
  } else {
    fnscale <- control$fnscale
    control$fnscale <- NULL
    fnscale <- fnscale[1]
    stopifnot(is.numeric(fnscale))
  }
  parscale <- control$parscale
  
  fg <- parallel_fg_generator(fn=fn, gr=gr, args_list=dots,
                              lower=lower, upper=upper, 
                              cl=parallel$cl, ndeps=control$ndeps,
                              fnscale=fnscale, parscale=parscale,
                              parnames=names(par))
  
 
  out <-  trust.optim(x=par, fn=fg$f,
                      gr =fg$g,
                      hs = NULL,
                      method = method,
                      control = list(
                        start.trust.radius=5,
                        #stop.trust.radius = 1e-3,
                        #prec=1e-3,
                        maxit=150
                      )) 
  
  #out$value <- out$value*fnscale
  out$`fval` <- out$`fval`*fnscale
  
  out
}


parallel_fg_generator <- function(fn, gr=NULL, args_list=list(),
                                  lower=-Inf, upper=Inf,
                                  cl=cl, ndeps=1e-3, fnscale=1, parscale=1,
                                  parnames=NULL){

  if(any(is.na(lower))) lower[is.na(lower)] <- -Inf
  if(any(is.na(upper))) lower[is.na(upper)] <- Inf
  
  if(is.null(fnscale)) fnscale <- 1
  if(is.null(parscale)) parscale <- 1
  
  eval <- function(par){
    ## the first argument of fn has to be a vector of length length(par)
    if(identical(par, par_last))
      return(list(value=value, grad=grad))
    if(is.null(gr)){
      n <- length(par)
      ndeps <- ndeps*parscale
      ndeps_mat <- array(0, c(n,n))
      ndeps_vec <- rep(ndeps, length.out=n)
      diag(ndeps_mat) <- ndeps_vec
 # two sided
        ndepsused <- 2*ndeps_vec
        PAR <- data.frame(cbind(array(par, c(n,n))+ndeps_mat, array(par, c(n,n))-ndeps_mat))
        if(!(is.null(upper) || all(is.na(upper)) || all(upper==Inf))){
          hitu <- unlist(lapply(PAR, function(par){any(par>upper)}))
          if(any(hitu)){
            PAR[hitu] <- par
            hitui <- apply(matrix(hitu, ncol=2), 1, any)
            ndepsused[hitui] <- ndeps_vec[hitui] 
          }
        }
        if(!(is.null(lower) || all(is.na(lower)) || all(lower==Inf))){
          hitl <- unlist(lapply(PAR, function(par){any(par<lower)}))
          if(any(hitl)){
            PAR[hitl] <- par
            hitli <- apply(matrix(hitl, ncol=2), 1, any)
            ndepsused[hitli] <- ndeps_vec[hitli] 
          }
        }
        PAR <- cbind(PAR, par)
        e <- unname(unlist(evalParallel(cl=cl, f=fn, args=args_list, firstArg=PAR, parnames=parnames)))
        e <- e/fnscale
        value <- e[length(e)]
        length(e) <- length(e)-1
        e_mat <- matrix(e, ncol=2)
        grad <- c(e_mat[,1]-e_mat[,2])/ndepsused
      
    }else{ # gr is not null
      funlist <- list(getFunctions(f=fn, args=args_list, firstArg=par, parnames=parnames)[[1]],
                      getFunctions(f=gr, args=args_list, firstArg=par, parnames=parnames)[[1]])
      res <- parallel::parLapply(cl=cl, X=funlist, fun=function(x) x())
      value <- res[[1]]/fnscale 
      grad <- res[[2]]/fnscale 
    }
    if(is.null(optimlog)){
      optimlog <- c(i_e+1, par, value, grad, use.names=FALSE)
      names(optimlog) <- c("iter", paste0("par", seq_along(par)), "fn", paste0("gr", seq_along(par)))
    }
    else{
      optimlog <- rbind(optimlog, c(i_e+1, par, value=value, grad=grad))
      rownames(optimlog) <- NULL
    }
    par_last <<- par
    value <<- value
    grad <<- grad
    optimlog <<- optimlog
    i_e <<- i_e+1
    return(list(value=value, grad=grad))
  }
  f <- function(par){
    eval(par) 
    i_f <<- i_f+1
    return(value)
  }
  g <- function(par){
    eval(par) 
    i_g <<- i_g+1
    return(grad)
  }
  init <- function(){
    i_f <<- i_g <<- i_e <<- 0
    par_last <<- value <<- grad <<- NA
  }
  getCount <- function(){
    c(i_e, i_f, i_g)
  }
  getLog <- function(){
    optimlog
  }
  i_f <- i_g <- i_e <- 0
  par_last <- value <- grad <- NA
  optimlog <- NULL
  list(f=f, g=g, init=init, eval=eval, getCount=getCount, getLog=getLog)
}

parallel_fg_generator <- compiler::cmpfun(parallel_fg_generator)
trust.optimParallel <- compiler::cmpfun(trust.optimParallel)