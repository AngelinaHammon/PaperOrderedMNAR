
loglik_bivprob_est_aghq <- function(data, yS, yO, XO, XS, kS, kO, group,sel, out, QP,...) {
  
  r_start <- suppressWarnings(glmer(sel,data=data,family=binomial(link=probit)))
  sigma1 <- r_start@theta^2 # -> Varianzwert -> noch log() bilden 
  if(round(sigma1,6)==0){sigma1 <- 0.0001}
  
  # Startwerte outcome equation: 
  y_start <- suppressWarnings(glmer(out,data=data[which(as.numeric(yS)==1),],family=binomial(link=probit)))
  sigma2 <- y_start@theta^2 # -> Varianzwert -> noch log() bilden
  if(round(sigma2,6)==0){sigma2 <- 0.0001}
  
  start <- c(r_start@beta,y_start@beta, atanh(0.5) ,log(sigma1), log(sigma2) ,atanh(0.5))
  
  cl <- parallel::makeCluster(2)
  
  parallel::setDefaultCluster(cl)
  
  parallel::clusterEvalQ(cl, {
    library(Rcpp)
    library(RcppArmadillo)
    library(corpcor)
    library(statmod)
    library(maxLik)
    library(PanelCount)
    library(VGAM)
    library(lme4)
    library(Matrix)
    library(compiler)
    library(nloptr)
    library(trustOptim)
    library(bivprob.quad)})
  
  opt <- trust.optimParallel(par=start, fn=loglik_bivprob_aghq, gr =loglik_bivprob_grad_aghq ,method = "BFGS",
                             yS=yS, yO=yO, XO=XO, XS=XS, kS=kS, kO=kO, group=group,QP=QP)
  
  parallel::stopCluster(cl)

  hess <- numericHessian(loglik_bivprob_aghq,gr=loglik_bivprob_grad_aghq,t0=opt$solution, yS=yS, yO=yO, XO=XO, XS=XS, kS=kS, kO=kO, group=group,QP=QP)
  if(any(is.na(hess))==T) {
    hess <- numericHessian(loglik_bivprob_aghq,gr=NULL,t0=opt$solution, yS=yS, yO=yO, XO=XO, XS=XS, kS=kS, kO=kO, group=group,QP=QP)
  }

  res <- list(estimates=opt$solution,hessian=hess)
  
  return(res)
}

loglik_bivprob_est_aghq <- compiler::cmpfun(loglik_bivprob_est_aghq)
