

loglik_bivprob_est_ghq <- function(data, yS, yO, XO, XS, kS, kO, group,sel, out, QP,...) {
  
  r_start <- suppressWarnings(glmer(sel,data=data,family=binomial(link=probit)))
  sigma1 <- r_start@theta^2 # -> Varianzwert -> noch log() bilden 
  if(round(sigma1,6)==0){sigma1 <- 0.0001}
  
  # Startwerte outcome equation: 
  y_start <- suppressWarnings(glmer(out,data=data[which(as.numeric(yS)==1),],family=binomial(link=probit)))
  sigma2 <- y_start@theta^2 # -> Varianzwert -> noch log() bilden
  if(round(sigma2,6)==0){sigma2 <- 0.0001}
  

  start <- c(r_start@beta,y_start@beta, atanh(0.5) ,log(sigma1), log(sigma2) ,atanh(0.5))

  opt <- optim(par=start, fn=loglik_bivprob_ghq, gr=NULL, method="BFGS", yS, yO, XO, XS, kS, kO, group,QP)
 
  hess <- numericHessian(loglik_bivprob_ghq,gr=NULL,t0=opt$par, yS=yS, yO=yO, XO=XO, XS=XS, kS=kS, kO=kO, group=group,QP=QP)
  
  res <- list(estimates=opt$par,hessian=hess)
  
  return(res)
}

loglik_bivprob_est_ghq <- compiler::cmpfun(loglik_bivprob_est_ghq)
