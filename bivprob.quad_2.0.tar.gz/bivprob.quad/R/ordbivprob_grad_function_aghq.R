
loglik_ordbivprob_grad_aghq <- function(param, yS, yO, XO, XS, kS, kO, group,QP,...) {
  
  # get categories of yO:
  if(is.factor(yO)==T) {
    cat <- levels(yO)
  }else{
    cat <- unique(yO)[order(unique(yO))]
  }
  
  betaS    <- param[1:kS]
  betaO    <- param[(kS+1):(kS+kO)]
  rho      <- tanh(param[kS+kO+1])
  z        <- param[(kS+kO+2):(kS+kO+2+length(cat)-2)]
  z_trans <- z
  sigma1   <- exp(param[(kS+kO+2+length(cat)-2+1)])
  sigma2   <- exp(param[(kS+kO+2+length(cat)-2+2)])
  tau      <- tanh(param[length(param)])
  
  # retransform:
  for(i in 2:length(z)){
    z[i] <- exp(z[i])+z[i-1]
  }
  

  group_aux <- c(0,cumsum(table(as.integer(factor(group)))))
  
  
  # calculate nodes and weights for given quadrature points:
  rule1 = gauss.quad(QP[1], "hermite")
  
  rule = list(w_1=rule1$weights, a_1=rule1$nodes)
  
  w1 <- rule$w_1
  a1 <- rule$a_1
  
  
  M <- length(table(group)) 
  N <- length(yS)
  
  # linear predictors:
  linpredS <- XS %*% betaS 
  linpredO <- XO %*% betaO
  
  yO <- as.numeric(as.character(yO))
  
  levels <- as.numeric(as.character(unique(yO[order(yO)])))
  
  # calculate mode and curvature:
  # mode:
  start2 <- c(0,0)
  
  modes <- t(sapply(1:length(table(group)), function(x) { # Funktion wird auf alle Cluster angewandt 
    optim(par=start2, fn=mode_ord, gr=NULL, method="Nelder-Mead", x=x, yS=yS, yO=yO, linpredS=linpredS, linpredO=linpredO, group_aux=group_aux,rho=rho,z=z,tau=tau,
          sigma1=sigma1,sigma2=sigma2,levels=levels)$par
  })) 
  
  
  # hessian of mode:
  hess_mode <- lapply(1:nrow(modes), function(x) { 
    numericHessian(f=mode_ord, grad=NULL, t0=modes[x,], x=x, yS=yS, yO=yO, linpredS=linpredS, linpredO=linpredO, group_aux=group_aux,rho=rho,z=z,tau=tau,
                   sigma1=sigma1,sigma2=sigma2,levels=levels)
  })
  

  
  if(any(sapply(1:nrow(modes),function(x) is.na(hess_mode[[x]])) == T)) {
    hess_mode <- lapply(1:nrow(modes),function(x) diag(2))
  }
  
  if(any(sapply(1:nrow(modes),function(x) isSymmetric(hess_mode[[x]])) == F)) {
    hess_mode <- lapply(1:nrow(modes),function(x) as.matrix(forceSymmetric(hess_mode[[x]])))
  }
  
  hess_mode <- lapply(1:nrow(modes),function(x) make.positive.definite(hess_mode[[x]]))
  
  det_curv <- sapply(1:nrow(modes),function(x) det(hess_mode[[x]])^(-1/2))
  solve_hess_mode <- lapply(1:nrow(modes),function(x) make.positive.definite(solve(hess_mode[[x]],tol=1.2e-300)))
  solve_hess_mode <- lapply(1:nrow(modes),function(x) as.matrix(nearPD(solve_hess_mode[[x]])$mat))
  chol_curv <- lapply(1:nrow(modes),function(x) t(chol(solve_hess_mode[[x]])))
  
  
  if(round(tau,2)==1){
    tau <- 0.9999
  }
  
  if(round(tau,2)==-1){
    tau <- -0.9999
  }
  
  if(round(rho,2)==1){
    rho <- 0.9999
  }
  
  if(round(rho,2)==-1){
    rho <- -0.9999
  }
  
  
  if(sigma1 > 700){
    sigma1 <- exp(700)
  }
  
  if(sigma2 > 700){
    sigma2 <- exp(700)
  }
  
  if(sigma1 < -700){
    sigma1 <- exp(-700)
  }
  
  if(sigma2 < -700){
    sigma2 <- exp(-700)
  }
  
  group <- as.integer(factor(group))
  
  dloglik <- loop_grad_ord(yS, yO, XS, XO, linpredS, linpredO, rho, tau, sigma1, sigma2, z, z_trans, levels, w1, a1, group_aux, group, M, modes, det_curv, chol_curv) 
  
  # Total Log-Likelihood:
  return(dloglik)
  
  
}

loglik_ordbivprob_grad_aghq <- compiler::cmpfun(loglik_ordbivprob_grad_aghq)